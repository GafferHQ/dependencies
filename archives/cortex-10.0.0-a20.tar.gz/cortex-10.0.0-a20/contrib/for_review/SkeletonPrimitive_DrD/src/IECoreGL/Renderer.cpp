//////////////////////////////////////////////////////////////////////////
//
//  Copyright (c) 2007-2010, Image Engine Design Inc. All rights reserved.
//
//  Redistribution and use in source and binary forms, with or without
//  modification, are permitted provided that the following conditions are
//  met:
//
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in the
//       documentation and/or other materials provided with the distribution.
//
//     * Neither the name of Image Engine Design nor the names of any
//       other contributors to this software may be used to endorse or
//       promote products derived from this software without specific prior
//       written permission.
//
//  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
//  IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
//  THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
//  PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
//  CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
//  EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
//  PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
//  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
//  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
//  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
//  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
//////////////////////////////////////////////////////////////////////////

#include "IECoreGL/Renderer.h"
#include "IECoreGL/State.h"
#include "IECoreGL/PointsPrimitive.h"
#include "IECoreGL/MeshPrimitive.h"
#include "IECoreGL/QuadPrimitive.h"
#include "IECoreGL/SpherePrimitive.h"
#include "IECoreGL/ColorTexture.h"
#include "IECoreGL/LuminanceTexture.h"
#include "IECoreGL/Scene.h"
#include "IECoreGL/Group.h"
#include "IECoreGL/GL.h"
#include "IECoreGL/private/DeferredRendererImplementation.h"
#include "IECoreGL/private/ImmediateRendererImplementation.h"
#include "IECoreGL/private/Display.h"
#include "IECoreGL/TypedStateComponent.h"
#include "IECoreGL/ShaderManager.h"
#include "IECoreGL/Shader.h"
#include "IECoreGL/ShaderStateComponent.h"
#include "IECoreGL/TextureLoader.h"
#include "IECoreGL/PerspectiveCamera.h"
#include "IECoreGL/OrthographicCamera.h"
#include "IECoreGL/NameStateComponent.h"
#include "IECoreGL/ToGLCameraConverter.h"
#include "IECoreGL/CurvesPrimitive.h"
#include "IECoreGL/ToGLMeshConverter.h"
#include "IECoreGL/Font.h"
#include "IECoreGL/TextPrimitive.h"
#include "IECoreGL/DiskPrimitive.h"
#include "IECoreGL/ToGLCurvesConverter.h"
#include "IECoreGL/ToGLTextureConverter.h"
#include "IECoreGL/ToGLPointsConverter.h"
#include "IECoreGL/SkeletonPrimitive.h"

#include "IECore/MessageHandler.h"
#include "IECore/SimpleTypedData.h"
#include "IECore/BoxOps.h"
#include "IECore/Camera.h"
#include "IECore/Transform.h"
#include "IECore/MatrixAlgo.h"
#include "IECore/MeshPrimitive.h"
#include "IECore/MeshNormalsOp.h"
#include "IECore/SplineData.h"
#include "IECore/SplineToImage.h"
#include "IECore/CurvesPrimitive.h"
#include "IECore/PointsPrimitive.h"
#include "IECore/SkeletonPrimitive.h"

#include "OpenEXR/ImathBoxAlgo.h"

#include <stack>

using namespace IECore;
using namespace IECoreGL;
using namespace Imath;
using namespace std;

IE_CORE_DEFINERUNTIMETYPED( IECoreGL::Renderer );

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// static utility functions
/////////////////////////////////////////////////////////////////////////////////////////////////////////

template<typename T>
typename T::ConstPtr castWithWarning( ConstDataPtr data, const std::string &name, const std::string &context )
{
	typename T::ConstPtr c = runTimeCast<const T>( data );
	if( !c )
	{
		msg( Msg::Warning, context, boost::format( "Expected \"%s\" to be of type \"%s\"." ) % name % T::staticTypeName() );
	}
	return c;
}

template<typename T>
T parameterValue( const char *name, const CompoundDataMap &parameters, T defaultValue )
{
	CompoundDataMap::const_iterator it = parameters.find( name );
	if( it!=parameters.end() )
	{
		typename TypedData<T>::ConstPtr p = runTimeCast<const TypedData<T> >( it->second );
		if( p )
		{
			return p->readable();
		}
	}
	return defaultValue;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// member data held in a single structure
/////////////////////////////////////////////////////////////////////////////////////////////////////////

struct IECoreGL::Renderer::MemberData
{
	enum Mode
	{
		Immediate,
		Deferred
	};

	struct
	{
		Mode mode;
		V2f shutter;
		IECore::CompoundDataMap user;
		string fontSearchPath;
		string shaderSearchPath;
		string shaderSearchPathDefault;
		string shaderIncludePath;
		string shaderIncludePathDefault;
		string textureSearchPath;
		string textureSearchPathDefault;
		vector<CameraPtr> cameras;
		vector<DisplayPtr> displays;
		bool drawCoordinateSystems;
	} options;

	/// This is used only before worldBegin, so we can correctly get the transforms for cameras.
	/// After worldBegin the transform stack is taken care of by the backend implementations.
	std::stack<Imath::M44f> transformStack;

	bool inWorld;
	RendererImplementationPtr implementation;
	ShaderManagerPtr shaderManager;
	TextureLoaderPtr textureLoader;

	typedef std::map<std::string, GroupPtr> InstanceMap;
	InstanceMap instances;
	Group *currentInstance;

#ifdef IECORE_WITH_FREETYPE
	typedef std::map<std::string, FontPtr> FontMap;
	FontMap fonts;
#endif // IECORE_WITH_FREETYPE

};

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// structors
/////////////////////////////////////////////////////////////////////////////////////////////////////////

IECoreGL::Renderer::Renderer()
{
	m_data = new MemberData;

	m_data->options.mode = MemberData::Immediate;
	m_data->options.shutter = V2f( 0 );

	const char *fontPath = getenv( "IECORE_FONT_PATHS" );
	m_data->options.fontSearchPath = fontPath ? fontPath : "";
	const char *shaderPath = getenv( "IECOREGL_SHADER_PATHS" );
	m_data->options.shaderSearchPath = m_data->options.shaderSearchPathDefault = shaderPath ? shaderPath : "";
	const char *shaderIncludePath = getenv( "IECOREGL_SHADER_INCLUDE_PATHS" );
	m_data->options.shaderIncludePath = m_data->options.shaderIncludePathDefault = shaderIncludePath ? shaderIncludePath : "";
	const char *texturePath = getenv( "IECOREGL_TEXTURE_PATHS" );
	m_data->options.textureSearchPath = m_data->options.textureSearchPathDefault = texturePath ? texturePath : "";
	m_data->options.drawCoordinateSystems = false;

	m_data->transformStack.push( M44f() );

	m_data->inWorld = false;
	m_data->currentInstance = 0;
	m_data->implementation = 0;
	m_data->shaderManager = 0;
}

IECoreGL::Renderer::~Renderer()
{
	delete m_data;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// options etc
/////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef void (*OptionSetter)( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData );
typedef std::map<string, OptionSetter> OptionSetterMap;

typedef IECore::DataPtr (*OptionGetter)( const std::string &name, IECoreGL::Renderer::MemberData *memberData );
typedef std::map<string, OptionGetter> OptionGetterMap;

static void modeOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstStringDataPtr s = castWithWarning<StringData>( value, name, "Renderer::setOption" ) )
	{
		if( s->readable()=="immediate" )
		{
			memberData->options.mode = IECoreGL::Renderer::MemberData::Immediate;
		}
		else if( s->readable()=="deferred" )
		{
			memberData->options.mode = IECoreGL::Renderer::MemberData::Deferred;
		}
		else
		{
			msg( Msg::Warning, "Renderer::setOption", boost::format( "Unsuppported mode value \"%s\"." ) % s->readable() );
		}
	}
	return;
}

static IECore::DataPtr modeOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	switch( memberData->options.mode )
	{
		case IECoreGL::Renderer::MemberData::Immediate :
			return new StringData( "immediate" );
		default :
			return new StringData( "deferred" );
	}
}

static void shutterOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstV2fDataPtr s = castWithWarning<V2fData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.shutter = s->readable();
	}
}

static IECore::DataPtr shutterOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new V2fData( memberData->options.shutter );
}

static void fontSearchPathOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstStringDataPtr s = castWithWarning<StringData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.fontSearchPath = s->readable();
	}
}

static IECore::DataPtr fontSearchPathOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new StringData( memberData->options.fontSearchPath );
}

static void shaderSearchPathOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstStringDataPtr s = castWithWarning<StringData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.shaderSearchPath = s->readable();
	}
}

static IECore::DataPtr shaderSearchPathOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new StringData( memberData->options.shaderSearchPath );
}

static void shaderIncludePathOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstStringDataPtr s = castWithWarning<StringData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.shaderIncludePath = s->readable();
	}
}

static IECore::DataPtr shaderIncludePathOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new StringData( memberData->options.shaderIncludePath );
}

static void textureSearchPathOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstStringDataPtr s = castWithWarning<StringData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.textureSearchPath = s->readable();
	}
}

static IECore::DataPtr textureSearchPathOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new StringData( memberData->options.textureSearchPath );
}

static void drawCoordinateSystemsOptionSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	if( ConstBoolDataPtr b = castWithWarning<BoolData>( value, name, "Renderer::setOption" ) )
	{
		memberData->options.drawCoordinateSystems = b->readable();
	}
}

static IECore::DataPtr drawCoordinateSystemsOptionGetter( const std::string &name, IECoreGL::Renderer::MemberData *memberData )
{
	return new BoolData( memberData->options.drawCoordinateSystems );
}

static const OptionSetterMap *optionSetters()
{
	static OptionSetterMap *o = new OptionSetterMap;
	if( !o->size() )
	{
		(*o)["gl:mode"] = modeOptionSetter;
		(*o)["shutter"] = shutterOptionSetter;
		(*o)["searchPath:font"] = fontSearchPathOptionSetter;
		(*o)["gl:searchPath:shader"] = shaderSearchPathOptionSetter;
		(*o)["searchPath:shader"] = shaderSearchPathOptionSetter;
		(*o)["gl:searchPath:shaderInclude"] = shaderIncludePathOptionSetter;
		(*o)["searchPath:shaderInclude"] = shaderIncludePathOptionSetter;
		(*o)["gl:searchPath:texture"] = textureSearchPathOptionSetter;
		(*o)["searchPath:texture"] = textureSearchPathOptionSetter;
		(*o)["gl:drawCoordinateSystems"] = drawCoordinateSystemsOptionSetter;
	}
	return o;
}

static const OptionGetterMap *optionGetters()
{
	static OptionGetterMap *o = new OptionGetterMap;
	if( !o->size() )
	{
		(*o)["gl:mode"] = modeOptionGetter;
		(*o)["shutter"] = shutterOptionGetter;
		(*o)["searchPath:font"] = fontSearchPathOptionGetter;
		(*o)["gl:searchPath:shader"] = shaderSearchPathOptionGetter;
		(*o)["searchPath:shader"] = shaderSearchPathOptionGetter;
		(*o)["gl:searchPath:shaderInclude"] = shaderIncludePathOptionGetter;
		(*o)["searchPath:shaderInclude"] = shaderIncludePathOptionGetter;
		(*o)["gl:searchPath:texture"] = textureSearchPathOptionGetter;
		(*o)["searchPath:texture"] = textureSearchPathOptionGetter;
		(*o)["gl:drawCoordinateSystems"] = drawCoordinateSystemsOptionGetter;
	}
	return o;
}

void IECoreGL::Renderer::setOption( const std::string &name, IECore::ConstDataPtr value )
{
	if( m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::setOption", "Cannot call setOption after worldBegin()." );
		return;
	}

	const OptionSetterMap *o = optionSetters();
	OptionSetterMap::const_iterator it = o->find( name );
	if( it!=o->end() )
	{
		it->second( name, value, m_data );
	}
	else if( name.compare( 0, 5, "user:" )==0 )
	{
		m_data->options.user[name] = value->copy();
	}
	else if( name.compare( 0, 3, "gl:" )==0 || name.find( ':' )==string::npos )
	{
		msg( Msg::Warning, "Renderer::setOption", boost::format( "Unsuppported option \"%s\"." ) % name );
		return;
	}
}

IECore::ConstDataPtr IECoreGL::Renderer::getOption( const std::string &name ) const
{
	const OptionGetterMap *o = optionGetters();
	OptionGetterMap::const_iterator it = o->find( name );
	if( it!=o->end() )
	{
		return it->second( name, m_data );
	}
	else if( name.compare( 0, 5, "user:" )==0 )
	{
		IECore::CompoundDataMap::const_iterator it = m_data->options.user.find( name );
		if( it!=m_data->options.user.end() )
		{
			return it->second;
		}
		else
		{
			return 0;
		}
	}
	else if( name.compare( 0, 3, "gl:" )==0 || name.find( ':' )==string::npos )
	{
		msg( Msg::Warning, "Renderer::getOption", boost::format( "Unsuppported option \"%s\"." ) % name );
		return 0;
	}

	return 0;
}


void IECoreGL::Renderer::camera( const std::string &name, const IECore::CompoundDataMap &parameters )
{
	if( m_data->inWorld )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::camera", "Cameras can not be specified after worldBegin." );
		return;
	}
	if ( m_data->currentInstance )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::camera", "Cameras can not be specified during instance definition." );
		return;
	}

	try
	{
		IECore::CameraPtr coreCamera = new IECore::Camera( name, 0, new CompoundData( parameters ) );
		IECoreGL::CameraPtr camera = IECore::runTimeCast<IECoreGL::Camera>( ToGLCameraConverter( coreCamera ).convert() );
		// we have to store these till worldBegin, as only then are we sure what sort of renderer backend we have
		if( camera )
		{
			camera->setTransform( m_data->transformStack.top() );
			m_data->options.cameras.push_back( camera );
		}
	}
	catch( const std::exception &e )
	{
		msg( Msg::Error, "IECoreGL::Renderer::camera", e.what() );
		return;
	}
}


void IECoreGL::Renderer::display( const std::string &name, const std::string &type, const std::string &data, const IECore::CompoundDataMap &parameters )
{
	// we store displays till worldbegin, as until that point we don't have a renderer implementation to pass
	// them to
	if( m_data->inWorld )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::display", "Displays can not be specified after worldBegin." );
		return;
	}
	if ( m_data->currentInstance )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::display", "Displays can not be specified during instance definition." );
		return;
	}
	m_data->options.displays.push_back( new Display( name, type, data, parameters ) );
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// world begin/end
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void IECoreGL::Renderer::worldBegin()
{
	if( m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::worldBegin", "Cannot call worldBegin() again before worldEnd()." );
		return;
	}
	if ( m_data->currentInstance )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::worldBegin", "worldBegin can not be called during instance definition." );
		return;
	}

	m_data->inWorld = true;

	if( m_data->options.mode==MemberData::Deferred )
	{
		m_data->implementation = new DeferredRendererImplementation;
	}
	else
	{
		m_data->implementation = new ImmediateRendererImplementation;
	}

	if( m_data->options.shaderSearchPath==m_data->options.shaderSearchPathDefault && m_data->options.shaderIncludePath==m_data->options.shaderIncludePathDefault )
	{
		// use the shared default cache if we can
		m_data->shaderManager = ShaderManager::defaultShaderManager();
	}
	else
	{
		IECore::SearchPath includePaths( m_data->options.shaderIncludePath, ":" );
		m_data->shaderManager = new ShaderManager( IECore::SearchPath( m_data->options.shaderSearchPath, ":" ), &includePaths );
	}

	if( m_data->options.textureSearchPath==m_data->options.textureSearchPathDefault )
	{
		// use the shared default cache if we can
		m_data->textureLoader = TextureLoader::defaultTextureLoader();
	}
	else
	{
		m_data->textureLoader = new TextureLoader( IECore::SearchPath( m_data->options.textureSearchPath, ":" ) );
	}

	if( m_data->options.cameras.size() )
	{
		for( unsigned int i=0; i<m_data->options.cameras.size(); i++ )
		{
			m_data->implementation->addCamera( m_data->options.cameras[i] );
		}
	}
	else
	{
		// specify the default camera
		IECore::CameraPtr defaultCamera = new IECore::Camera();
		defaultCamera->addStandardParameters();
		IECoreGL::CameraPtr camera = IECore::runTimeCast<IECoreGL::Camera>( ToGLCameraConverter( defaultCamera ).convert() );
		m_data->implementation->addCamera( camera );
	}

	for( unsigned int i=0; i<m_data->options.displays.size(); i++ )
	{
		m_data->implementation->addDisplay( m_data->options.displays[i] );
	}
	m_data->implementation->worldBegin();
}

void IECoreGL::Renderer::worldEnd()
{
	if( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::worldEnd", "Cannot call worldEnd() before worldBegin()." );
		return;
	}
	if ( m_data->currentInstance )
	{
		msg( Msg::Warning, "IECoreGL::Renderer::worldEnd", "worldEnd can not be called during instance definition." );
		return;
	}
	m_data->implementation->worldEnd();
	m_data->inWorld = false;
}

ScenePtr IECoreGL::Renderer::scene()
{
	DeferredRendererImplementationPtr r = runTimeCast<DeferredRendererImplementation>( m_data->implementation );
	if( r )
	{
		return r->scene();
	}
	return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// transforms
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void IECoreGL::Renderer::transformBegin()
{
	if( m_data->inWorld )
	{
		m_data->implementation->transformBegin();
	}
	else
	{
		m_data->transformStack.push( m_data->transformStack.top() );
	}
}

void IECoreGL::Renderer::transformEnd()
{
	if( m_data->inWorld )
	{
		bool wasRight = ( determinant( m_data->implementation->getTransform() ) >= 0 );
		m_data->implementation->transformEnd();
		bool isRight = ( determinant( m_data->implementation->getTransform() ) >= 0 );

		if ( wasRight != isRight )
		{
			bool l = m_data->implementation->getState<RightHandedOrientationStateComponent>()->value();
			m_data->implementation->addState( new RightHandedOrientationStateComponent( !l ) );
		}
	}
	else
	{
		if( m_data->transformStack.size() )
		{
			m_data->transformStack.pop();
		}
		else
		{
			msg( Msg::Error, "IECoreGL::Renderer::transformEnd", "Bad nesting detected." );
		}
	}
}

void IECoreGL::Renderer::setTransform( const Imath::M44f &m )
{
	if( m_data->inWorld )
	{
		m_data->implementation->setTransform( m );

		if( determinant( m ) < 0.0f )
		{
			bool l = m_data->implementation->getState<RightHandedOrientationStateComponent>()->value();
			m_data->implementation->addState( new RightHandedOrientationStateComponent( !l ) );
		}
	}
	else
	{
		m_data->transformStack.top() = m;
	}
}

void IECoreGL::Renderer::setTransform( const std::string &coordinateSystem )
{
	msg( Msg::Warning, "Renderer::setTransform", "Not implemented" );
}

Imath::M44f IECoreGL::Renderer::getTransform() const
{
	if( m_data->inWorld )
	{
		return m_data->implementation->getTransform();
	}
	else
	{
		return m_data->transformStack.top();
	}
}

Imath::M44f IECoreGL::Renderer::getTransform( const std::string &coordinateSystem ) const
{
	msg( Msg::Warning, "Renderer::getTransform", "Not implemented" );
	return M44f();
}

void IECoreGL::Renderer::concatTransform( const Imath::M44f &m )
{
	if( m_data->inWorld )
	{
		m_data->implementation->concatTransform( m );
		if( determinant( m ) < 0.0f )
		{
			bool l = m_data->implementation->getState<RightHandedOrientationStateComponent>()->value();
			m_data->implementation->addState( new RightHandedOrientationStateComponent( !l ) );
		}
	}
	else
	{
		m_data->transformStack.top() = m * m_data->transformStack.top();
	}
}

void IECoreGL::Renderer::coordinateSystem( const std::string &name )
{
	if( m_data->options.drawCoordinateSystems )
	{
		IntVectorDataPtr numVerticesData = new IntVectorData;
		std::vector<int> &numVertices = numVerticesData->writable();
		numVertices.push_back( 2 );
		numVertices.push_back( 2 );
		numVertices.push_back( 2 );

		V3fVectorDataPtr pointsData = new V3fVectorData();
		std::vector<V3f> &points = pointsData->writable();
		points.push_back( V3f( 0 ) );
		points.push_back( V3f( 1, 0, 0 ) );
		points.push_back( V3f( 0 ) );
		points.push_back( V3f( 0, 1, 0 ) );
		points.push_back( V3f( 0 ) );
		points.push_back( V3f( 0, 0, 1 ) );

		PrimitiveVariableMap primVars;
		primVars["P"] = PrimitiveVariable( PrimitiveVariable::Vertex, pointsData );

		attributeBegin();
			setAttribute( "name", new StringData( "coordinateSystem:" + name ) );
			setAttribute( "gl:curvesPrimitive:useGLLines", new BoolData( true ) );
			setAttribute( "gl:curvesPrimitive:glLineWidth", new FloatData( 2 ) );
			curves( CubicBasisf::linear(), false, numVerticesData, primVars );
		attributeEnd();
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// attribute state
/////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef void (*AttributeSetter)( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData );
typedef std::map<string, AttributeSetter> AttributeSetterMap;
typedef IECore::ConstDataPtr (*AttributeGetter)( const std::string &name, const IECoreGL::Renderer::MemberData *memberData );
typedef std::map<string, AttributeGetter> AttributeGetterMap;

template<class T>
static void typedAttributeSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	typedef IECore::TypedData<typename T::ValueType> DataType;
	typename DataType::ConstPtr d = runTimeCast<const DataType>( value );
	if( !d )
	{
		msg( Msg::Warning, "Renderer::setAttribute", boost::format( "Expected data of type \"%s\" for attribute \"%s\"." ) % DataType::staticTypeName() % name );
		return;
	}
	memberData->implementation->addState( new T( d->readable() ) );
}

template<class T>
static IECore::ConstDataPtr typedAttributeGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	typedef IECore::TypedData<typename T::ValueType> DataType;
	const T *a = memberData->implementation->template getState<T>();
	return new DataType( a->value() );
}

static void colorAttributeSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstColor3fDataPtr d = castWithWarning<const Color3fData>( value, name, "Renderer::setAttribute" );
	if( d )
	{
		Color::ConstPtr c = memberData->implementation->getState<Color>();
		Color4f cc = c->value();
		cc[0] = d->readable()[0];
		cc[1] = d->readable()[1];
		cc[2] = d->readable()[2];
		memberData->implementation->addState( new Color( cc ) );
	}
}

static IECore::ConstDataPtr colorAttributeGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const IECoreGL::Color *a = memberData->implementation->getState<Color>();
	Color4f c = a->value();
	return new Color3fData( Color3f( c[0], c[1], c[2] ) );
}

static IECore::ConstDataPtr opacityAttributeGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const IECoreGL::Color *a = memberData->implementation->getState<Color>();
	Color4f c = a->value();
	return new Color3fData( Color3f( c[3] ) );
}

static void opacityAttributeSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstColor3fDataPtr d = castWithWarning<const Color3fData>( value, name, "Renderer::setAttribute" );
	if( d )
	{
		const Color *c = memberData->implementation->getState<Color>();
		Color4f cc = c->value();
		cc[3] = (d->readable()[0] + d->readable()[1] + d->readable()[2]) / 3.0f;
		memberData->implementation->addState( new Color( cc ) );
	}
}

static IECore::ConstDataPtr blendFactorGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const BlendFuncStateComponent *b = memberData->implementation->getState<BlendFuncStateComponent>();
	GLenum f = name=="gl:blend:srcFactor" ? b->value().src : b->value().dst;
	switch( f )
	{
		case GL_ZERO :
			return new StringData( "zero" );
		case GL_ONE :
			return new StringData( "one" );
		case GL_SRC_COLOR :
			return new StringData( "srcColor" );
		case GL_ONE_MINUS_SRC_COLOR :
			return new StringData( "oneMinusSrcColor" );
		case GL_DST_COLOR :
			return new StringData( "dstColor" );
		case GL_ONE_MINUS_DST_COLOR :
			return new StringData( "oneMinusDstColor" );
		case GL_SRC_ALPHA :
			return new StringData( "srcAlpha" );
		case GL_ONE_MINUS_SRC_ALPHA :
			return new StringData( "oneMinusSrcAlpha" );
		case GL_DST_ALPHA :
			return new StringData( "dstAlpha" );
		case GL_ONE_MINUS_DST_ALPHA :
			return new StringData( "oneMinusDstAlpha" );
		case GL_CONSTANT_COLOR :
			return new StringData( "constantColor" );
		case GL_ONE_MINUS_CONSTANT_COLOR :
			return new StringData( "oneMinusConstantColor" );
		case GL_CONSTANT_ALPHA :
			return new StringData( "constantAlpha" );
		case GL_ONE_MINUS_CONSTANT_ALPHA :
			return new StringData( "oneMinusConstantAlpha" );
		default :
			msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Invalid state for \"%s\"." ) % name );
			return new StringData( "invalid" );
	}
}

static void blendFactorSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}

	GLenum f;
	const std::string &v = d->readable();
	if( v=="zero" )
	{
		f = GL_ZERO;
	}
	else if( v=="one" )
	{
		f = GL_ONE;
	}
	else if( v=="srcColor" )
	{
		f = GL_SRC_COLOR;
	}
	else if( v=="oneMinusSrcColor" )
	{
		f = GL_ONE_MINUS_SRC_COLOR;
	}
	else if( v=="dstColor" )
	{
		f = GL_DST_COLOR;
	}
	else if( v=="oneMinusDstColor" )
	{
		f = GL_ONE_MINUS_DST_COLOR;
	}
	else if( v=="srcAlpha" )
	{
		f = GL_SRC_ALPHA;
	}
	else if( v=="oneMinusSrcAlpha" )
	{
		f = GL_ONE_MINUS_SRC_ALPHA;
	}
	else if( v=="dstAlpha" )
	{
		f = GL_DST_ALPHA;
	}
	else if( v=="oneMinusDstAlpha" )
	{
		f = GL_ONE_MINUS_DST_ALPHA;
	}
	else if( v=="constantColor" )
	{
		f = GL_CONSTANT_COLOR;
	}
	else if( v=="oneMinusConstantColor" )
	{
		f = GL_ONE_MINUS_CONSTANT_COLOR;
	}
	else if( v=="constantAlpha" )
	{
		f = GL_CONSTANT_ALPHA;
	}
	else if( v=="oneMinusConstantAlpha" )
	{
		f = GL_ONE_MINUS_CONSTANT_ALPHA;
	}
	else
	{
		msg( Msg::Error, "Renderer::setAttribute", boost::format( "Unsupported value \"%s\" for attribute \"%s\"." ) % v % name );
		return;
	}
	const BlendFuncStateComponent *b = memberData->implementation->getState<BlendFuncStateComponent>();
	BlendFactors bf = b->value();
	if( name=="gl:blend:srcFactor" )
	{
		bf.src = f;
	}
	else
	{
		bf.dst = f;
	}
	memberData->implementation->addState( new BlendFuncStateComponent( bf ) );
}

static IECore::ConstDataPtr blendEquationGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const BlendEquationStateComponent *b = memberData->implementation->getState<BlendEquationStateComponent>();
	switch( b->value() )
	{
		case GL_FUNC_ADD :
			return new StringData( "add" );
		case GL_FUNC_SUBTRACT :
			return new StringData( "subtract" );
		case GL_FUNC_REVERSE_SUBTRACT :
			return new StringData( "reverseSubtract" );
		case GL_MIN :
			return new StringData( "min" );
		case GL_MAX :
			return new StringData( "max" );
		default :
			msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Invalid state for \"%s\"." ) % name );
			return new StringData( "invalid" );
	}
}

static void blendEquationSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}

	GLenum f;
	const std::string &v = d->readable();
	if( v=="add" )
	{
		f = GL_FUNC_ADD;
	}
	else if( v=="subtract" )
	{
		f = GL_FUNC_SUBTRACT;
	}
	else if( v=="reverseSubtract" )
	{
		f = GL_FUNC_REVERSE_SUBTRACT;
	}
	else if( v=="min" )
	{
		f = GL_MIN;
	}
	else if( v=="max" )
	{
		f = GL_MAX;
	}
	else
	{
		msg( Msg::Error, "Renderer::setAttribute", boost::format( "Unsupported value \"%s\" for attribute \"%s\"." ) % v % name );
		return;
	}

	memberData->implementation->addState( new BlendEquationStateComponent( f ) );
}

static IECore::ConstDataPtr pointsPrimitiveUseGLPointsGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const IECoreGL::PointsPrimitive::UseGLPoints *b = memberData->implementation->getState<IECoreGL::PointsPrimitive::UseGLPoints>();
	switch( b->value() )
	{
		case ForPointsOnly :
			return new StringData( "forGLPoints" );
		case ForPointsAndDisks :
			return new StringData( "forParticlesAndDisks" );
		case ForAll :
			return new StringData( "forAll" );
		default :
			msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Invalid state for \"%s\"." ) % name );
			return new StringData( "invalid" );
	}

}

static void pointsPrimitiveUseGLPointsSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}
	GLPointsUsage u;
	const std::string &v = d->readable();
	if( v=="forGLPoints" )
	{
		u = ForPointsOnly;
	}
	else if( v=="forParticlesAndDisks" )
	{
		u = ForPointsAndDisks;
	}
	else if( v=="forAll" )
	{
		u = ForAll;
	}
	else
	{
		msg( Msg::Error, "Renderer::setAttribute", boost::format( "Unsupported value \"%s\" for attribute \"%s\"." ) % v % name );
		return;
	}
	memberData->implementation->addState( new IECoreGL::PointsPrimitive::UseGLPoints( u ) );
}

static IECore::ConstDataPtr nameGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	const NameStateComponent *n = memberData->implementation->getState<NameStateComponent>();
	return new StringData( n->name() );
}

static void nameSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}
	memberData->implementation->addState( new NameStateComponent( d->readable() ) );
}

static IECore::ConstDataPtr textPrimitiveTypeGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{

#ifdef IECORE_WITH_FREETYPE

	const TextPrimitive::Type *b = memberData->implementation->getState<TextPrimitive::Type>();
	switch( b->value() )
	{
		case TextPrimitive::Mesh :
			return new StringData( "mesh" );
		case TextPrimitive::Sprite :
			return new StringData( "sprite" );
		default :
			msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Invalid state for \"%s\"." ) % name );
			return new StringData( "invalid" );
	}

#else

	IECore::msg( IECore::Msg::Warning, "Renderer::getAttribute", "IECore was not built with FreeType support." );
	return 0;

#endif // IECORE_WITH_FREETYPE

}

static void textPrimitiveTypeSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{

#ifdef IECORE_WITH_FREETYPE

	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}
	TextPrimitive::RenderType t;
	const std::string &v = d->readable();
	if( v=="mesh" )
	{
		t = TextPrimitive::Mesh;
	}
	else if( v=="sprite" )
	{
		t = TextPrimitive::Sprite;
	}
	else
	{
		msg( Msg::Error, "Renderer::setAttribute", boost::format( "Unsupported value \"%s\" for attribute \"%s\"." ) % v % name );
		return;
	}
	memberData->implementation->addState( new TextPrimitive::Type( t ) );

#else

	IECore::msg( IECore::Msg::Warning, "Renderer::setAttribute", "IECore was not built with FreeType support." );

#endif // IECORE_WITH_FREETYPE

}

template<class T>
static IECore::ConstDataPtr rendererSpaceGetter( const std::string &name, const IECoreGL::Renderer::MemberData *memberData )
{
	typename T::ConstPtr b = memberData->implementation->getState< T >();
	switch( b->value() )
	{
		case ObjectSpace :
			return new StringData( "object" );
		case WorldSpace :
			return new StringData( "world" );
		default :
			msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Invalid state for \"%s\"." ) % name );
			return new StringData( "invalid" );
	}
}

template<class T>
static void rendererSpaceSetter( const std::string &name, IECore::ConstDataPtr value, IECoreGL::Renderer::MemberData *memberData )
{
	ConstStringDataPtr d = castWithWarning<const StringData>( value, name, "Renderer::setAttribute" );
	if( !d )
	{
		return;
	}
	RendererSpace s;
	const std::string &v = d->readable();
	if( v=="object" )
	{
		s = ObjectSpace;
	}
	else if ( v == "world" )
	{
		s = WorldSpace;
	}
	else
	{
		msg( Msg::Error, "Renderer::setAttribute", boost::format( "Unsupported value \"%s\" for attribute \"%s\"." ) % v % name );
		return;
	}
	memberData->implementation->addState( new T( s ) );
}

static const AttributeSetterMap *attributeSetters()
{
	static AttributeSetterMap *a = new AttributeSetterMap;
	if( !a->size() )
	{
		(*a)["gl:primitive:wireframe"] = typedAttributeSetter<IECoreGL::Primitive::DrawWireframe>;
		(*a)["gl:primitive:wireframeWidth"] = typedAttributeSetter<IECoreGL::Primitive::WireframeWidth>;
		(*a)["gl:primitive:bound"] = typedAttributeSetter<IECoreGL::Primitive::DrawBound>;
		(*a)["gl:primitive:solid"] = typedAttributeSetter<IECoreGL::Primitive::DrawSolid>;
		(*a)["gl:primitive:outline"] = typedAttributeSetter<IECoreGL::Primitive::DrawOutline>;
		(*a)["gl:primitive:outlineWidth"] = typedAttributeSetter<IECoreGL::Primitive::OutlineWidth>;
		(*a)["gl:primitive:points"] = typedAttributeSetter<IECoreGL::Primitive::DrawPoints>;
		(*a)["gl:primitive:pointWidth"] = typedAttributeSetter<IECoreGL::Primitive::PointWidth>;
		(*a)["gl:primitive:sortForTransparency"] = typedAttributeSetter<IECoreGL::Primitive::TransparencySort>;
		(*a)["gl:primitive:wireframeColor"] = typedAttributeSetter<WireframeColorStateComponent>;
		(*a)["gl:primitive:boundColor"] = typedAttributeSetter<BoundColorStateComponent>;
		(*a)["gl:primitive:outlineColor"] = typedAttributeSetter<OutlineColorStateComponent>;
		(*a)["gl:primitive:pointColor"] = typedAttributeSetter<PointColorStateComponent>;
		(*a)["gl:color"] = typedAttributeSetter<Color>;
		(*a)["color"] = colorAttributeSetter;
		(*a)["opacity"] = opacityAttributeSetter;
		(*a)["gl:blend:color"] = typedAttributeSetter<BlendColorStateComponent>;
		(*a)["gl:blend:srcFactor"] = blendFactorSetter;
		(*a)["gl:blend:dstFactor"] = blendFactorSetter;
		(*a)["gl:blend:equation"] = blendEquationSetter;
		(*a)["gl:shade:transparent"] = typedAttributeSetter<TransparentShadingStateComponent>;
		(*a)["gl:pointsPrimitive:useGLPoints"] = pointsPrimitiveUseGLPointsSetter;
		(*a)["gl:pointsPrimitive:glPointWidth"] = typedAttributeSetter<IECoreGL::PointsPrimitive::GLPointWidth>;
		(*a)["name"] = nameSetter;
		(*a)["doubleSided"] = typedAttributeSetter<DoubleSidedStateComponent>;
		(*a)["rightHandedOrientation"] = typedAttributeSetter<RightHandedOrientationStateComponent>;
		(*a)["gl:curvesPrimitive:useGLLines"] = typedAttributeSetter<IECoreGL::CurvesPrimitive::UseGLLines>;
		(*a)["gl:curvesPrimitive:glLineWidth"] = typedAttributeSetter<IECoreGL::CurvesPrimitive::GLLineWidth>;
		(*a)["gl:curvesPrimitive:ignoreBasis"] = typedAttributeSetter<IECoreGL::CurvesPrimitive::IgnoreBasis>;
		(*a)["gl:smoothing:points"] = typedAttributeSetter<PointSmoothingStateComponent>;
		(*a)["gl:smoothing:lines"] = typedAttributeSetter<LineSmoothingStateComponent>;
		(*a)["gl:smoothing:polygons"] = typedAttributeSetter<PolygonSmoothingStateComponent>;
		(*a)["gl:textPrimitive:type"] = textPrimitiveTypeSetter;
		(*a)["gl:cullingSpace"] = rendererSpaceSetter<CullingSpaceStateComponent>;
		(*a)["gl:cullingBox"] = typedAttributeSetter<CullingBoxStateComponent>;
		(*a)["gl:procedural:reentrant"] = typedAttributeSetter<ProceduralThreadingStateComponent>;
	}
	return a;
}

static const AttributeGetterMap *attributeGetters()
{
	static AttributeGetterMap *a = new AttributeGetterMap;
	if( !a->size() )
	{
		(*a)["gl:primitive:wireframe"] = typedAttributeGetter<IECoreGL::Primitive::DrawWireframe>;
		(*a)["gl:primitive:wireframeWidth"] = typedAttributeGetter<IECoreGL::Primitive::WireframeWidth>;
		(*a)["gl:primitive:bound"] = typedAttributeGetter<IECoreGL::Primitive::DrawBound>;
		(*a)["gl:primitive:solid"] = typedAttributeGetter<IECoreGL::Primitive::DrawSolid>;
		(*a)["gl:primitive:outline"] = typedAttributeGetter<IECoreGL::Primitive::DrawOutline>;
		(*a)["gl:primitive:outlineWidth"] = typedAttributeGetter<IECoreGL::Primitive::OutlineWidth>;
		(*a)["gl:primitive:points"] = typedAttributeGetter<IECoreGL::Primitive::DrawPoints>;
		(*a)["gl:primitive:pointWidth"] = typedAttributeGetter<IECoreGL::Primitive::PointWidth>;
		(*a)["gl:primitive:sortForTransparency"] = typedAttributeGetter<IECoreGL::Primitive::TransparencySort>;
		(*a)["gl:primitive:wireframeColor"] = typedAttributeGetter<WireframeColorStateComponent>;
		(*a)["gl:primitive:boundColor"] = typedAttributeGetter<BoundColorStateComponent>;
		(*a)["gl:primitive:outlineColor"] = typedAttributeGetter<OutlineColorStateComponent>;
		(*a)["gl:primitive:pointColor"] = typedAttributeGetter<PointColorStateComponent>;
		(*a)["gl:color"] = typedAttributeGetter<Color>;
		(*a)["color"] = colorAttributeGetter;
		(*a)["opacity"] = opacityAttributeGetter;
		(*a)["gl:blend:color"] = typedAttributeGetter<BlendColorStateComponent>;
		(*a)["gl:blend:srcFactor"] = blendFactorGetter;
		(*a)["gl:blend:dstFactor"] = blendFactorGetter;
		(*a)["gl:blend:equation"] = blendEquationGetter;
		(*a)["gl:shade:transparent"] = typedAttributeGetter<TransparentShadingStateComponent>;
		(*a)["gl:pointsPrimitive:useGLPoints"] = pointsPrimitiveUseGLPointsGetter;
		(*a)["gl:pointsPrimitive:glPointWidth"] = typedAttributeGetter<IECoreGL::PointsPrimitive::GLPointWidth>;
		(*a)["name"] = nameGetter;
		(*a)["doubleSided"] = typedAttributeGetter<DoubleSidedStateComponent>;
		(*a)["rightHandedOrientation"] = typedAttributeGetter<RightHandedOrientationStateComponent>;
		(*a)["gl:curvesPrimitive:useGLLines"] = typedAttributeGetter<IECoreGL::CurvesPrimitive::UseGLLines>;
		(*a)["gl:curvesPrimitive:glLineWidth"] = typedAttributeGetter<IECoreGL::CurvesPrimitive::GLLineWidth>;
		(*a)["gl:curvesPrimitive:ignoreBasis"] = typedAttributeGetter<IECoreGL::CurvesPrimitive::IgnoreBasis>;
		(*a)["gl:smoothing:points"] = typedAttributeGetter<PointSmoothingStateComponent>;
		(*a)["gl:smoothing:lines"] = typedAttributeGetter<LineSmoothingStateComponent>;
		(*a)["gl:smoothing:polygons"] = typedAttributeGetter<PolygonSmoothingStateComponent>;
		(*a)["gl:textPrimitive:type"] = textPrimitiveTypeGetter;
		(*a)["gl:cullingSpace"] = rendererSpaceGetter<CullingSpaceStateComponent>;
		(*a)["gl:cullingBox"] = typedAttributeGetter<CullingBoxStateComponent>;
		(*a)["gl:procedural:reentrant"] = typedAttributeGetter<ProceduralThreadingStateComponent>;
	}
	return a;
}

void IECoreGL::Renderer::attributeBegin()
{
	if ( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::attributeBegin", "Unsupported attributeBegin outside world begin/end blocks." );
		return;
	}
	m_data->implementation->attributeBegin();
}

void IECoreGL::Renderer::attributeEnd()
{
	if ( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::attributeBegin", "Unsupported attributeBegin outside world begin/end blocks." );
		return;
	}
	m_data->implementation->attributeEnd();
}

void IECoreGL::Renderer::setAttribute( const std::string &name, IECore::ConstDataPtr value )
{
	if ( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::setAttribute", "Unsupported setAttribute outside world begin/end blocks." );
		return;
	}
	const AttributeSetterMap *s = attributeSetters();
	AttributeSetterMap::const_iterator it = s->find( name );
	if( it!=s->end() )
	{
		it->second( name, value, m_data );
	}
	else if( name.compare( 0, 5, "user:" )==0 )
	{
		m_data->implementation->addUserAttribute( name, value->copy() );
	}
	else if( name.find_first_of( ":" )!=string::npos )
	{
		// prefixed for some other renderer, so we can ignore it
	}
	else
	{
		msg( Msg::Warning, "Renderer::setAttribute", boost::format( "Unsupported attribute \"%s\"." ) % name );
	}
}

IECore::ConstDataPtr IECoreGL::Renderer::getAttribute( const std::string &name ) const
{
	if ( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::getAttribute", "Unsupported getAttribute outside world begin/end blocks." );
		return 0;
	}

	const AttributeGetterMap *g = attributeGetters();
	AttributeGetterMap::const_iterator it = g->find( name );
	if( it!=g->end() )
	{
		return it->second( name, m_data );
	}
	else if( name.compare( 0, 5, "user:" )==0 )
	{
		return m_data->implementation->getUserAttribute( name );
	}
	else if( name.find_first_of( ":" )!=string::npos )
	{
		// prefixed for some other renderer, so we can ignore it
		return 0;
	}
	else
	{
		msg( Msg::Warning, "Renderer::getAttribute", boost::format( "Unsupported attribute \"%s\"." ) % name );
	}
	return 0;
}

void IECoreGL::Renderer::shader( const std::string &type, const std::string &name, const IECore::CompoundDataMap &parameters )
{
	if ( !m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::shader", "Unsupported shader call outside world begin/end blocks." );
		return;
	}

	if( type=="surface" || type=="gl:surface" )
	{
		if ( !m_data->shaderManager )
		{
			msg( Msg::Warning, "Renderer::shader", "Shader specification before world begin ignored. No ShaderManager defined yet." );
			return;
		}
		string vertexSource = parameterValue<string>( "gl:vertexSource", parameters, "" );
		string fragmentSource = parameterValue<string>( "gl:fragmentSource", parameters, "" );

		if ( vertexSource == "" && fragmentSource == "" )
		{
			m_data->shaderManager->loadShaderCode( name, vertexSource, fragmentSource );
		}

		// validate the parameter types and load any texture parameters.
		ShaderStateComponentPtr shaderState = new ShaderStateComponent( m_data->shaderManager, m_data->textureLoader, vertexSource, fragmentSource );
		for( CompoundDataMap::const_iterator it=parameters.begin(); it!=parameters.end(); it++ )
		{
			if( it->first!="gl:fragmentSource" && it->first!="gl:vertexSource" )
			{
				shaderState->addShaderParameterValue( it->first.value(), it->second );
			}
		}
		m_data->implementation->addState( shaderState );
	}
	else
	{
		msg( Msg::Warning, "Renderer::shader", boost::format( "Unsupported shader type \"%s\"." ) % type );
	}
}

void IECoreGL::Renderer::light( const std::string &name, const std::string &handle, const IECore::CompoundDataMap &parameters )
{
	msg( Msg::Warning, "Renderer::light", "Not implemented" );
}

void IECoreGL::Renderer::illuminate( const std::string &lightHandle, bool on )
{
	msg( Msg::Warning, "Renderer::illuminate", "Not implemented" );
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// motion
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void IECoreGL::Renderer::motionBegin( const std::set<float> &times )
{
	msg( Msg::Warning, "Renderer::motionBegin", "Not implemented" );
}

void IECoreGL::Renderer::motionEnd()
{
	msg( Msg::Warning, "Renderer::motionEnd", "Not implemented" );
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// primitives
/////////////////////////////////////////////////////////////////////////////////////////////////////////

template< typename T >
static bool checkCulling( RendererImplementation *r, const T *p )
{
	const Imath::Box3f &cullBox = r->getState<CullingBoxStateComponent>()->value();
	if ( cullBox.isEmpty() )
	{
		// culling is disabled... p should be rendered.
		return true;
	}

	Imath::Box3f b = p->bound();
	switch( r->getState<CullingSpaceStateComponent>()->value() )
	{
		case ObjectSpace :
			// if in local space we don't have to transform bounding box of p.
			break;
		case WorldSpace :
			// transform procedural bounding box to world space to match culling box space.
			b = Imath::transform( b, r->getTransform() );
			break;
		default :
			msg( Msg::Warning, "Renderer::checkCulling", "Unnexpected culling space!" );
			return true;
	}
	return cullBox.intersects( b );
}

static void addPrimVarsToPrimitive( IECoreGL::PrimitivePtr primitive, const IECore::PrimitiveVariableMap &primVars )
{
	// add primVars to the gl primitive
	for( IECore::PrimitiveVariableMap::const_iterator it=primVars.begin(); it!=primVars.end(); it++ )
	{
		try
		{
			primitive->addPrimitiveVariable( it->first, it->second );
		}
		catch( const std::exception &e )
		{
			IECore::msg( IECore::Msg::Error, "Renderer::addPrimitive", boost::format( "Failed to add primitive variable %s (%s)." ) % it->first % e.what() );
		}
	}
}

static void addCurrentInstanceChild( IECoreGL::Renderer::MemberData *data, IECoreGL::Renderable *child )
{
	IECoreGL::GroupPtr childGroup = new IECoreGL::Group();
	childGroup->setTransform( data->transformStack.top() );
	childGroup->addChild( child );
	data->currentInstance->addChild( childGroup );
}

void IECoreGL::Renderer::points( size_t numPoints, const IECore::PrimitiveVariableMap &primVars )
{
	try
	{
		IECore::PointsPrimitivePtr p = new IECore::PointsPrimitive( numPoints );
		p->variables = primVars;
		IECoreGL::PointsPrimitivePtr prim = IECore::staticPointerCast<IECoreGL::PointsPrimitive>( ToGLPointsConverter( p ).convert() );
		if ( m_data->currentInstance )
		{
			addCurrentInstanceChild( m_data, prim );
		}
		else if ( checkCulling< IECoreGL::Primitive >( m_data->implementation, prim ) )
		{
			m_data->implementation->addPrimitive( prim );
		}
	}
	catch( const std::exception &e )
	{
		msg( Msg::Warning, "Renderer::points", e.what() );
		return;
	}
}

void IECoreGL::Renderer::disk( float radius, float z, float thetaMax, const IECore::PrimitiveVariableMap &primVars )
{
	DiskPrimitivePtr prim = new DiskPrimitive( radius, z, thetaMax );
	addPrimVarsToPrimitive( prim, primVars );
	if ( m_data->currentInstance )
	{
		addCurrentInstanceChild( m_data, prim );
	}
	else if ( checkCulling< IECoreGL::Primitive >( m_data->implementation, prim ) )
	{
		m_data->implementation->addPrimitive( prim );
	}
}

void IECoreGL::Renderer::curves( const IECore::CubicBasisf &basis, bool periodic, IECore::ConstIntVectorDataPtr numVertices, const IECore::PrimitiveVariableMap &primVars )
{
	try
	{
		IECore::CurvesPrimitivePtr c = new IECore::CurvesPrimitive( numVertices, basis, periodic );
		c->variables = primVars;
		CurvesPrimitivePtr prim = IECore::staticPointerCast<CurvesPrimitive>( ToGLCurvesConverter( c ).convert() );
		if ( m_data->currentInstance )
		{
			addCurrentInstanceChild( m_data, prim );
		}
		else if ( checkCulling< IECoreGL::Primitive >( m_data->implementation, prim ) )
		{
			m_data->implementation->addPrimitive( prim );
		}
	}
	catch( const std::exception &e )
	{
		msg( Msg::Warning, "Renderer::curves", e.what() );
		return;
	}
}

void IECoreGL::Renderer::text( const std::string &font, const std::string &text, float kerning, const IECore::PrimitiveVariableMap &primVars )
{

#ifdef IECORE_WITH_FREETYPE
	FontPtr f = 0;
	MemberData::FontMap::const_iterator it = m_data->fonts.find( font );
	if( it!=m_data->fonts.end() )
	{
		f = it->second;
	}
	else
	{
		IECore::SearchPath s( m_data->options.fontSearchPath, ":" );
		string file = s.find( font ).string();
		if( file!="" )
		{
			try
			{
				IECore::FontPtr cf = new IECore::Font( file );
				cf->setResolution( 128 ); // makes for better texture resolutions - maybe it could be an option?
				f = new Font( cf );
			}
			catch( const std::exception &e )
			{
				IECore::msg( IECore::Msg::Warning, "Renderer::text", e.what() );
			}
		}
		m_data->fonts[font] = f;
	}

	if( !f )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::text", boost::format( "Font \"%s\" not found." ) % font );
		return;
	}

	f->coreFont()->setKerning( kerning );

	TextPrimitivePtr prim = new TextPrimitive( text, f );
	addPrimVarsToPrimitive( prim, primVars );
	if ( m_data->currentInstance )
	{
		addCurrentInstanceChild( m_data, prim );
	}
	else if ( checkCulling< IECoreGL::Primitive >( m_data->implementation, prim ) )
	{
		m_data->implementation->addPrimitive( prim );
	}
#else
	IECore::msg( IECore::Msg::Warning, "Renderer::text", "IECore was not built with FreeType support." );
#endif // IECORE_WITH_FREETYPE
}

void IECoreGL::Renderer::sphere( float radius, float zMin, float zMax, float thetaMax, const IECore::PrimitiveVariableMap &primVars )
{
	SpherePrimitivePtr prim = new SpherePrimitive( radius, zMin, zMax, thetaMax );
	addPrimVarsToPrimitive( prim, primVars );
	if ( m_data->currentInstance )
	{
		addCurrentInstanceChild( m_data, prim );
	}
	else if ( checkCulling< IECoreGL::Primitive >( m_data->implementation, prim ) )
	{
		m_data->implementation->addPrimitive( prim );
	}
}

static const std::string &imageFragmentShader()
{
	// fragment shader
	static const std::string shaderCode =
		"uniform sampler2D texture;"
		""
		"void main()"
		"{"
		"	gl_FragColor = texture2D( texture, gl_TexCoord[0].xy );"
		"}";
	return shaderCode;
}

/// \todo This positions images incorrectly when dataWindow!=displayWindow. This is because the texture
/// contains only the dataWindow contents, but we've positioned the card as if it will contain the whole
/// displayWindow.
void IECoreGL::Renderer::image( const Imath::Box2i &dataWindow, const Imath::Box2i &displayWindow, const IECore::PrimitiveVariableMap &primVars )
{
	if ( m_data->currentInstance )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::image", "Images currently not supported inside instances." );
		return;
	}

	ImagePrimitivePtr image = new ImagePrimitive( dataWindow, displayWindow );

	if ( !checkCulling<IECore::Primitive>( m_data->implementation, image ) )
	{
		return;
	}

	image->variables = primVars;

	IECore::CompoundObjectPtr params = new IECore::CompoundObject();
	params->members()[ "texture" ] = image;

	ShaderStateComponentPtr shaderState = new ShaderStateComponent( m_data->shaderManager, m_data->textureLoader, "", imageFragmentShader(), params );

	m_data->implementation->transformBegin();

		Box3f bound = image->bound();
		V3f center = bound.center();

		M44f xform;
		xform[3][0] = center.x;
		xform[3][1] = center.y;
		xform[3][2] = center.z;

		xform[0][0] = boxSize( bound ).x ;
		xform[1][1] = boxSize( bound ).y ;
		xform[2][2] = 1.0;

		m_data->implementation->concatTransform( xform );
		m_data->implementation->attributeBegin();
		m_data->implementation->addState( shaderState );
		QuadPrimitivePtr quad = new QuadPrimitive( 1.0, 1.0 );
		m_data->implementation->addPrimitive( quad );
		m_data->implementation->attributeEnd();

	m_data->implementation->transformEnd();
}

void IECoreGL::Renderer::mesh( IECore::ConstIntVectorDataPtr vertsPerFace, IECore::ConstIntVectorDataPtr vertIds, const std::string &interpolation, const IECore::PrimitiveVariableMap &primVars )
{
	try
	{
		IECore::MeshPrimitivePtr m = new IECore::MeshPrimitive( vertsPerFace, vertIds, interpolation );
		m->variables = primVars;

		if( interpolation!="linear" )
		{
			// it's a subdivision mesh. in the absence of a nice subdivision algorithm to display things with,
			// we can at least make things look a bit nicer by calculating some smooth shading normals.
			// if interpolation is linear and no normals are provided then we assume the faceted look is intentional.
			if( primVars.find( "N" )==primVars.end() )
			{
				MeshNormalsOpPtr normalOp = new MeshNormalsOp();
				normalOp->inputParameter()->setValue( m );
				normalOp->copyParameter()->setTypedValue( false );
				normalOp->operate();
			}
		}

		ToGLMeshConverterPtr meshConverter = new ToGLMeshConverter( m );
		MeshPrimitivePtr prim = IECore::staticPointerCast<MeshPrimitive>( meshConverter->convert() );
		if ( m_data->currentInstance )
		{
			addCurrentInstanceChild( m_data, prim );
		}
		else if ( checkCulling<IECoreGL::Primitive>( m_data->implementation, prim ) )
		{
			m_data->implementation->addPrimitive( prim );
		}
	}
	catch( const std::exception &e )
	{
		msg( Msg::Warning, "Renderer::mesh", e.what() );
		return;
	}
}

void IECoreGL::Renderer::skeleton(
		IECore::ConstM44fVectorDataPtr globalMatrices, IECore::ConstIntVectorDataPtr parentIds,
		bool displayAxis, float jointsSize,
		const PrimitiveVariableMap &primVars )
{
	SkeletonPrimitivePtr prim = new SkeletonPrimitive(globalMatrices, parentIds, displayAxis, jointsSize, primVars);
	// m->variables = primVars;
	if ( checkCulling<IECoreGL::Primitive>( m_data->implementation, prim ) )
	{
		m_data->implementation->addPrimitive( prim );
	}
}

void IECoreGL::Renderer::nurbs( int uOrder, IECore::ConstFloatVectorDataPtr uKnot, float uMin, float uMax, int vOrder, IECore::ConstFloatVectorDataPtr vKnot, float vMin, float vMax, const IECore::PrimitiveVariableMap &primVars )
{
	msg( Msg::Warning, "Renderer::nurbs", "Not implemented" );
}

void IECoreGL::Renderer::patchMesh( const IECore::CubicBasisf &uBasis, const IECore::CubicBasisf &vBasis, int nu, bool uPeriodic, int nv, bool vPeriodic, const IECore::PrimitiveVariableMap &primVars )
{
	msg( Msg::Warning, "Renderer::patchMesh", "Not implemented" );
}

void IECoreGL::Renderer::geometry( const std::string &type, const IECore::CompoundDataMap &topology, const IECore::PrimitiveVariableMap &primVars )
{
	if( type=="sphere" )
	{
		float radius = parameterValue<float>( "radius", topology, 1 );
		float zMin = parameterValue<float>( "zMin", topology, -1 );
		float zMax = parameterValue<float>( "zMax", topology, 1 );
		float thetaMax = parameterValue<float>( "thetaMax", topology, 360 );
		sphere( radius, zMin, zMax, thetaMax, primVars );
	}
	else
	{
		msg( Msg::Warning, "Renderer::geometry", boost::format( "Geometry type \"%s\" not implemented." ) % type );
	}
}

void IECoreGL::Renderer::procedural( IECore::Renderer::ProceduralPtr proc )
{
	if ( m_data->currentInstance )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::procedural", "Procedurals currently not supported inside instances." );
		return;
	}
	if ( checkCulling<IECore::Renderer::Procedural>( m_data->implementation, proc ) )
	{
		m_data->implementation->addProcedural( proc, this );
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// instancing
/////////////////////////////////////////////////////////////////////////////////////////////////////////

void IECoreGL::Renderer::instanceBegin( const std::string &name, const IECore::CompoundDataMap &parameters )
{
	if ( m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::instanceBegin", "Unsupported instanceBegin call after worldBegin." );
		return;
	}
	if ( m_data->currentInstance )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::instanceBegin", "Instance already being defined!" );
		return;
	}
	MemberData::InstanceMap::const_iterator it = m_data->instances.find( name );
	if ( it != m_data->instances.end() )
	{
		msg( Msg::Warning, "Renderer::instance", boost::format( "Overwriting instance named \"%s\"." ) % name );
		return;
	}
	m_data->currentInstance = new Group();
	m_data->instances[ name ] = m_data->currentInstance;
}

void IECoreGL::Renderer::instanceEnd()
{
	if ( m_data->inWorld )
	{
		msg( Msg::Warning, "Renderer::instanceEnd", "Unsupported instanceEnd call after worldBegin." );
		return;
	}
	if ( !m_data->currentInstance )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::instanceEnd", "instanceEnd called when no instances are being defined!" );
		return;
	}
	m_data->currentInstance = 0;
}

void IECoreGL::Renderer::instance( const std::string &name )
{
	MemberData::InstanceMap::iterator it = m_data->instances.find( name );
	if ( it == m_data->instances.end() )
	{
		msg( Msg::Warning, "Renderer::instance", boost::format( "No instance named \"%s\" was found." ) % name );
		return;
	}
	if ( m_data->currentInstance )
	{
		// instance called within another instance
		addCurrentInstanceChild( m_data, it->second );
	}
	else if ( m_data->inWorld )
	{
		m_data->implementation->addInstance( it->second );
	}
	else
	{
		msg( Msg::Warning, "Renderer::instance", "Unsupported call to instance outside world and instance block!" );
	}
}

/////////////////////////////////////////////////////////////////////////////////////////////////////////
// commands
/////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef IECore::DataPtr (*Command)( const std::string &name, const IECore::CompoundDataMap &parameters, IECoreGL::Renderer::MemberData *memberData );
typedef std::map<string, Command> CommandMap;

bool removeObjectWalk( IECoreGL::GroupPtr parent, IECoreGL::GroupPtr child, const std::string &objectName )
{
	ConstNameStateComponentPtr stateName = child->getState()->get<NameStateComponent>();
	if( stateName && stateName->name()==objectName )
	{
		if( parent )
		{
			IECoreGL::Group::Mutex::scoped_lock lock( parent->mutex() );
			parent->removeChild( child );
		}
		else
		{
			// no parent, ie we're at the root of the Scene. just remove all the children.
			IECoreGL::Group::Mutex::scoped_lock lock( child->mutex() );
			child->clearChildren();
		}
		return true;
	}

	bool result = false;
	IECoreGL::Group::Mutex::scoped_lock lock( child->mutex() );
	IECoreGL::Group::ChildContainer::const_iterator it = child->children().begin();
	while( it!=child->children().end() )
	{
		IECoreGL::GroupPtr g = IECore::runTimeCast<IECoreGL::Group>( *it );
		it++;
		if( g )
		{
			result = result | removeObjectWalk( child, g, objectName );
		}
	}
	if ( result && child->children().size() == 0 && parent )
	{
		// group after removal became empty, remove it too.
		IECoreGL::Group::Mutex::scoped_lock lock( parent->mutex() );
		parent->removeChild( child );
	}
	return result;
}

IECore::DataPtr removeObjectCommand( const std::string &name, const IECore::CompoundDataMap &parameters, IECoreGL::Renderer::MemberData *memberData )
{
	DeferredRendererImplementationPtr r = runTimeCast<DeferredRendererImplementation>( memberData->implementation );
	if( !r )
	{
		msg( Msg::Warning, "Renderer::command", "removeObject command operates only in deferred mode" );
		return 0;
	}

	string objectName = parameterValue<string>( "name", parameters, "" );
	if( objectName=="" )
	{
		msg( Msg::Warning, "Renderer::command", "removeObject command expects StringData parameter \"name\"" );
		return 0;
	}

	ScenePtr scene = r->scene();
	bool result = removeObjectWalk( 0, r->scene()->root(), objectName );

	return new IECore::BoolData( result );
}

IECore::DataPtr editBeginCommand( const std::string &name, const IECore::CompoundDataMap &parameters, IECoreGL::Renderer::MemberData *memberData )
{
	DeferredRendererImplementationPtr r = runTimeCast<DeferredRendererImplementation>( memberData->implementation );
	if( !r )
	{
		msg( Msg::Warning, "Renderer::command", "editBeginCommand command operates only in deferred mode" );
		return 0;
	}

	memberData->inWorld = true;
	return new IECore::BoolData( true );
}

IECore::DataPtr editEndCommand( const std::string &name, const IECore::CompoundDataMap &parameters, IECoreGL::Renderer::MemberData *memberData )
{
	DeferredRendererImplementationPtr r = runTimeCast<DeferredRendererImplementation>( memberData->implementation );
	if( !r )
	{
		msg( Msg::Warning, "Renderer::command", "editEndCommand command operates only in deferred mode" );
		return 0;
	}

	memberData->inWorld = false;
	return new IECore::BoolData( true );
}

static const CommandMap &commands()
{
	static CommandMap c;
	if( !c.size() )
	{
		c["removeObject"] = removeObjectCommand;
		c["editBegin"] = editBeginCommand;
		c["editEnd"] = editEndCommand;
	}
	return c;
}

IECore::DataPtr IECoreGL::Renderer::command( const std::string &name, const IECore::CompoundDataMap &parameters )
{
	if ( m_data->currentInstance )
	{
		IECore::msg( IECore::Msg::Warning, "Renderer::command", "Commands not supported inside instances." );
		return 0;
	}
	const CommandMap &c = commands();
	CommandMap::const_iterator it = c.find( name );
	if( it!=c.end() )
	{
		return it->second( name, parameters, m_data );
	}

	if( name.compare( 0, 3, "gl:" )==0 || name.find( ':' )==string::npos )
	{
		msg( Msg::Warning, "Renderer::command", boost::format( "Unsuppported command \"%s\"." ) % name );
		return 0;
	}

	return 0;
}

IECoreGL::ShaderManager *IECoreGL::Renderer::shaderManager()
{
	return m_data->shaderManager;
}

IECoreGL::TextureLoader *IECoreGL::Renderer::textureLoader()
{
	return m_data->textureLoader;
}
