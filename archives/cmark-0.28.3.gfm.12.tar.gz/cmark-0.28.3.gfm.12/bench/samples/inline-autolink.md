closed (valid) autolinks:

 <ftp://1.2.3.4:21/path/foo>
 <http://foo.bar.baz?q=hello&id=22&boolean>
 <http://veeeeeeeeeeeeeeeeeeery.loooooooooooooooooooooooooooooooong.autolink/>
 <teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeest@gmail.com>

these are not autolinks:

 <ftp://1.2.3.4:21/path/foo
 <http://foo.bar.baz?q=hello&id=22&boolean
 <http://veeeeeeeeeeeeeeeeeeery.loooooooooooooooooooooooooooooooong.autolink
 <teeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeest@gmail.com
 < http://foo.bar.baz?q=hello&id=22&boolean >
