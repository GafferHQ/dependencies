#!/usr/bin/env python

command = testshade("-g 3 3 --param a 10.0 test")
