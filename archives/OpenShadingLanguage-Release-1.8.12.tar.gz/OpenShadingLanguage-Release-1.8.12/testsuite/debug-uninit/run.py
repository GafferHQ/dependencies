#!/usr/bin/env python

command = testshade("--debuguninit -o Cout Cout.tif test")
