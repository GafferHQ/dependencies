#!/usr/bin/env python

outputs = [ "out.exr" ]
command = testrender("-r 320 240 -aa 4 veach.xml out.exr")
