#!/usr/bin/env python

outputs = [ "out.exr" ]
command = testrender("-r 320 240 -aa 20 scene.xml out.exr")
