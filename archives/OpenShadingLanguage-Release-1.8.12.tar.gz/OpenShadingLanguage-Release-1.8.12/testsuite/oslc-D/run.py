#!/usr/bin/env python

command = oslc ("-Dfoo=bar test.osl")
command += testshade ("test")
