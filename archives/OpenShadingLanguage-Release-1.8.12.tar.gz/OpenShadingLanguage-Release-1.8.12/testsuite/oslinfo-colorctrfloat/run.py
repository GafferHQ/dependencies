#!/usr/bin/env python 

command = oslinfo("-v test")
