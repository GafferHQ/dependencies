#!/usr/bin/env python 

command = oslc("test_variadic_macro.osl")
