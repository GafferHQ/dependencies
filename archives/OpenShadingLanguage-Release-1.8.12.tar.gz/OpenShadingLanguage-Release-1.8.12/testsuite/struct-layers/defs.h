struct coords {
    float s, t;
};

struct shading_result {
   closure color Cout;
   color Copac;
};
