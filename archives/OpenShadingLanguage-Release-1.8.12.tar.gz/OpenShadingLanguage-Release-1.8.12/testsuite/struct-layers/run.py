#!/usr/bin/env python

command += testshade("--layer alayer a --layer blayer b --connect alayer st_out.s blayer x.s --connect alayer st_out.t blayer x.t --connect alayer st_out blayer y --connect alayer r blayer r")
