#!/usr/bin/env python

command = testshade("-param myparam 0.25 -param myparam 1.0 test")
