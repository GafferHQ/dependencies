#!/usr/bin/env python

command = testshade("test")

