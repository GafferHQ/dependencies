#!/usr/bin/env python

command = testshade("--raytype glossy test")
