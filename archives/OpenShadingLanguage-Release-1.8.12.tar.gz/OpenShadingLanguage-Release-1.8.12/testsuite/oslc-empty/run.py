#!/usr/bin/env python

command = oslc("-d test.osl")
