#!/usr/bin/env python

command = testshade("-g 2 2 test")
