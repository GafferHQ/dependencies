#!/usr/bin/env python

command = testshade("--debugnan -g 2 2 -o Cout Cout.tif test")
