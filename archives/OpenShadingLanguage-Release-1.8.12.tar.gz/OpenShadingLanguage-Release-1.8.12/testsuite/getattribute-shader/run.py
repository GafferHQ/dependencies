#!/usr/bin/env python

# Simple test on a grid texture
command = testshade("-groupname Beatles -layer Cake test")
