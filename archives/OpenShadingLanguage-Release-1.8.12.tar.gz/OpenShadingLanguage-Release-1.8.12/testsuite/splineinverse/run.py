#!/usr/bin/env python

command = testshade("-g 3 1 --center test")
