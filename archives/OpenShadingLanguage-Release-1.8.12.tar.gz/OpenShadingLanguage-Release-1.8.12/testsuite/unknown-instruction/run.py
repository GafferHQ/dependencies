#!/usr/bin/env python

# Test what happens when an oso file contains an unknown instruction

command = testshade("data/test")
