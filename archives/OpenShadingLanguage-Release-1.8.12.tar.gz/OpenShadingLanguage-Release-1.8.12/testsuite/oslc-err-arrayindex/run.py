#!/usr/bin/env python

# command = oslc("test.osl")
# don't even need that -- it's automatic
failureok = 1     # this test is expected to have oslc errors
