
struct Astruct {
    float s, t;
};
