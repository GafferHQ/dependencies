#!/usr/bin/env python

command = testshade("--layer a a --layer b b --connect a Aout b Ain -o Cout out.exr")
