#!/usr/bin/env python

command += testshade("--options lazyglobals=0 -layer alayer a --layer blayer b --connect alayer out blayer in")
