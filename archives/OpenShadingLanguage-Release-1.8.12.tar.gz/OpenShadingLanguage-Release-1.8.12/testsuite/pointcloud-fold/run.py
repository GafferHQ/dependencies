#!/usr/bin/env python

command += testshade("-param radius 1000.0 -param filename data/cloud.geo rdcloud")
