#!/usr/bin/env python 

command += testshade("-group data/serial.oslgroup")
