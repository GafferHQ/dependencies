#!/usr/bin/env python 

# Simple test on a grid texture
command = testshade("-g 1 1 test")
