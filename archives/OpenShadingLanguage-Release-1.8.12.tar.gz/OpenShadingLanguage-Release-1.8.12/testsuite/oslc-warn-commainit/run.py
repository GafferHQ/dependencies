#!/usr/bin/env python

# command = oslc("test.osl")
# don't even need that -- it's automatic
