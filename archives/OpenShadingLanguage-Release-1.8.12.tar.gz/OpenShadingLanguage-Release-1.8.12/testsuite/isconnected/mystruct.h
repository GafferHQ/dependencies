struct MyStruct {
    float x;
    float y;
};
