#!/usr/bin/env python

command += testshade("-g 1000 64 -od float -o Cout out.exr test")
outputs = [ "out.txt", "out.exr" ]
